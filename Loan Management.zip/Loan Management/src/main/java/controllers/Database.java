/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Database {
	public static void main(String[] args) throws SQLException {
		Connection c=Database.connect();
		Statement st=c.createStatement();
		ResultSet rs=st.executeQuery("select * from admin_details");
		while(rs.next()) {
			System.out.println(rs.getString(1));
		}
	}

    public static Connection con;

    //This method returns the database connection
    public static Connection connect() {
        try {
        	System.out.println("checking...");
            Class.forName("com.mysql.cj.jdbc.Driver");
            String password="@M1o2h3a4n5";
            String user="root";
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/loanmanagementsystemdb", user,password);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        System.out.println(con);
        return con;
    }
}